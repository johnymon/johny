<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Main_model');
		$this->load->database();
		$this->load->helper('url');

	}
	public function index()
	{
		$this->home();
	}

	public function home()
	{
		$this->load->view('templates/header');
		$this->load->view('pages/home');
		$this->load->view('templates/footer');
	}
	public function login()
	{
		$this->load->view('templates/header');
		$this->load->view('pages/login');
		$this->load->view('templates/footer');
	}
	public function register()
	{
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		if($this->input->post('register'))
		{
			$this->form_validation->set_rules(
				'name', 'Name',
				'required|min_length[3]','regex_match[/[a-zA-Z]/]',
				array(
						'required'      => 'You have not provided %s.',
						'min_length'    => '%s must be have 3 charecter',
						'regex_match'   => 'charechter only'
				)
		);
		$this->form_validation->set_rules(
			'phone', 'Phone',
			'required|min_length[10]|max_length[10]|is_unique[register.phone]',
			array(
					'required'      => 'You have not provided %s.',
					'is_unique'     => 'This %s already exists.',
					'min_length'    => 'Enter valid %s number',
					'max_length'    => 'Enter valid %s number'
			)
	);
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[register.email]');

		if ($this->form_validation->run() == TRUE)
		{
			$this->Main_model->register();
		} 
		}
		$this->load->view('templates/header');
		$this->load->view('pages/register');
		$this->load->view('templates/footer');
	}
}

?>