
<h1>Register</h1>


<?php echo validation_errors(); ?>


<form action="" method="post" name="reg_form">
    <table>
    <tr>
        <td><label for="name">Name</label></td>
        <td><input type="text" name="name" id="name" value="<?php echo set_value('name'); ?>"></td>
    </tr>
    <tr>
        <td><label for="Email">Email</label></td>
        <td><input type="email" name="email" id="email" value="<?php echo set_value('email'); ?>"></td>
    </tr>
    <tr>
        <td><label for="paswword">Password</label></td>
        <td><input type="password" name="password" id="password" value="<?php echo set_value('password'); ?>"></td>
    </tr>
    <tr>
        <td><label for="phone">Phone</label></td>
        <td><input type="number" name="phone" id="phone"></td>
    </tr>
    <tr>
        <td><input type="submit" value="Register" name="register"></td>
    </tr>
    </table>
</form>
