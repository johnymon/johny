
<h1>Login</h1>
<form action="" method="post">
    <table>
    <tr>
        <td><label for="Email">Email</label></td>
        <td><input type="email" name="email" id="email"></td>
    </tr>
    <tr>
        <td><label for="paswword">Password</label></td>
        <td><input type="password" name="password" id="password"></td>
    </tr>
    <tr>
        <td><input type="submit" value="Login" name="login"></td>
    </tr>
    </table>
</form>
