<?php
class Main_model extends CI_Model {

    public function register()
    {
        $data = array(
                'name' => $_POST['name'],
                'email' => $_POST['email'],
                'password' => $_POST['password'],
                'phone' => $_POST['phone']
        );
        
        $this->db->insert('register', $data);
    }
    
    public function login()
    {
        $this->title    = $_POST['title']; 
        $this->content  = $_POST['content'];
        $this->date     = time();

        $this->db->insert('register', $this);
    }

    public function update_entry()
    {
        $this->title    = $_POST['title'];
        $this->content  = $_POST['content'];
        $this->date     = time();

        $this->db->update('entries', $this, array('id' => $_POST['id']));
    }
    
    }
?>